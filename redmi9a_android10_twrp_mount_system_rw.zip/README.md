# redmi9a_android10_twrp_mount_system_rw
- 让红米9a安卓10在twrp下可以修改system分区
- 下载后自行打包成zip文件，然后用twrp进行刷入，效果为一次性的，每次修改都要刷入
- 压缩文件内的目录务必为META-INF、.gitattributes、LICENSE、README.md，否则twrp不认
